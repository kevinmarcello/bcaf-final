package com.bcaf.bus.helper;

public class ToastMessage {
}

package com.bcaf.bus.network;

public class ConfigDatabase {

    //Base URL
    public static final String BASE_URL = "http://13.213.140.15:8080/bus/api/";

}
